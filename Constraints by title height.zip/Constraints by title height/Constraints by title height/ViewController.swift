//
//  ViewController.swift
//  Constraints by title height
//
//  Created by Christoffer Mouritsen on 17/03/2022.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let titels = ["This one has one line", "This has two lines in contrast to having one line", "This one has three linjes which is why I have to write this many letters. I need to wirte some more letters", "This one has three linjes which is why I have to write this many letters. I need to wirte some more letters", "This has two lines in contrast to having one line", "This one has one line", "This one has one line", "This has two lines in contrast to having one line", "This one has three linjes which is why I have to write this many letters. I need to wirte some more letters"]

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        titels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        self.tableView.separatorStyle = .none
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellClass") as! cellClass
        
        cell.setCell(titelText: titels[indexPath.row])
        let margineGuide = cell.layoutMarginsGuide
        NSLayoutConstraint.activate([
            cell.titel.trailingAnchor.constraint(equalTo: margineGuide.trailingAnchor, constant: -20),
            cell.bullet1.trailingAnchor.constraint(equalTo: margineGuide.trailingAnchor, constant: -20),
            cell.bullet2.trailingAnchor.constraint(equalTo: margineGuide.trailingAnchor, constant: -20),
            cell.bullet3.trailingAnchor.constraint(equalTo: margineGuide.trailingAnchor, constant: -20),
            cell.titel.leadingAnchor.constraint(equalTo: margineGuide.leadingAnchor, constant: 20),
            cell.bullet1.leadingAnchor.constraint(equalTo: margineGuide.leadingAnchor, constant: 20),
            cell.bullet2.leadingAnchor.constraint(equalTo: margineGuide.leadingAnchor, constant: 20),
            cell.bullet3.leadingAnchor.constraint(equalTo: margineGuide.leadingAnchor, constant: 20),
        ])
        print("Cell number \(indexPath.row + 1) has \(cell.titel.calculateMaxLines()) lines")
    if (cell.titel.calculateMaxLines() == 3) {
        NSLayoutConstraint.activate([
            cell.bullet1.topAnchor.constraint(equalTo: cell.titel.bottomAnchor, constant: 12),
            cell.bullet2.topAnchor.constraint(equalTo: cell.bullet1.bottomAnchor, constant: 12),
            cell.bullet3.topAnchor.constraint(equalTo: cell.bullet2.bottomAnchor, constant: 12)
        ])
    } else if (cell.titel.calculateMaxLines() == 2) {
        NSLayoutConstraint.activate([
            cell.bullet1.topAnchor.constraint(equalTo: cell.titel.bottomAnchor, constant: 18),
            cell.bullet2.topAnchor.constraint(equalTo: cell.bullet1.bottomAnchor, constant: 18),
            cell.bullet3.topAnchor.constraint(equalTo: cell.bullet2.bottomAnchor, constant: 18)
        ])
    } else {
        NSLayoutConstraint.activate([
            cell.bullet1.topAnchor.constraint(equalTo: cell.titel.bottomAnchor, constant: 24),
            cell.bullet2.topAnchor.constraint(equalTo: cell.bullet1.bottomAnchor, constant: 24),
            cell.bullet3.topAnchor.constraint(equalTo: cell.bullet2.bottomAnchor, constant: 24)
        ])
    }
        
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
           return CGFloat(240)
       }
    
}

class cellClass:UITableViewCell {
    
    let titel = UILabel()
    
    let bullet1 = UILabel()
    
    let bullet2 = UILabel()
    
    let bullet3 = UILabel()
    
    func setCell(titelText: String) {
        titel.translatesAutoresizingMaskIntoConstraints = false
        titel.text = titelText
        titel.numberOfLines = 0;
        self.addSubview(titel)
        
        bullet1.translatesAutoresizingMaskIntoConstraints = false
        bullet1.text = "Bullet1"
        self.addSubview(bullet1)
        
        bullet2.translatesAutoresizingMaskIntoConstraints = false
        bullet2.text = "Bullet2"
        self.addSubview(bullet2)
        
        bullet3.translatesAutoresizingMaskIntoConstraints = false
        bullet3.text = "Bullet3"
        self.addSubview(bullet3)
    }
}

extension UILabel {
    func calculateMaxLines() -> Int {
        let maxSize = CGSize(width: frame.size.width, height: CGFloat(Float.infinity))
        let charSize = font.lineHeight
        let text = (self.text ?? "") as NSString
        let textSize = text.boundingRect(with: maxSize, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font as Any], context: nil)
        let linesRoundedUp = Int(ceil(textSize.height/charSize))
        return linesRoundedUp
    }
}
